import pandas as pd
import sklearn
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

sklearn.preprocessing.StandardScaler()

data = pd.read_csv('D:\课题\订书肽\project\原始/原始数据.CSV')

datanum = data.iloc[:, 3:]
dataid = data.iloc[:, :3]

columns = datanum.columns

print(datanum)
print(dataid)

print("data:\n", data)

transfer = StandardScaler()

for col in columns:

    column_data = data[col].values.reshape(-1, 1)
    scaled_data = transfer .fit_transform(column_data)
    data[col] = scaled_data
print("data:\n", data)
data = pd.DataFrame(data)
print("data:\n", data)
data = data.iloc[0:]
print("data:\n", data)

data.to_csv("D:\课题\订书肽\project\predict result/标准化结果总.CSV", index=False)