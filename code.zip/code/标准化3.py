import pandas as pd
from sklearn.preprocessing import StandardScaler

# 读取数据
data = pd.read_csv('D:\课题\订书肽\project\原始/原始数据.CSV')

# 分离特征和标签
datanum = data.iloc[:, 3:]
dataid = data.iloc[:, :3]

# 标准化训练集
scaler = StandardScaler()
datanum_scaled = scaler.fit_transform(datanum)
datanum = pd.DataFrame(datanum_scaled, columns=datanum.columns)

# 输出标准化后的训练集
print("Standardized training data:\n", datanum)

# 读取测试集
test = pd.read_csv('D:\课题\订书肽\project\原始/样本数据筛.CSV')

# 分离特征和标签
testnum = test.iloc[:, 3:]
testid = test.iloc[:, :3]


# 使用已经训练好的scaler对象来标准化测试集
testnum_scaled = scaler.transform(testnum)
testnum = pd.DataFrame(testnum_scaled, columns=testnum.columns)

# 输出标准化后的测试集
print("Standardized test data:\n", testnum)

# 将测试集的前三列和标准化后的测试集合并
test_result = pd.concat([testid, testnum], axis=1)


# 保存标准化后的测试集
test_result.to_csv("D:\课题\订书肽\project\predict result/标准化结果总2.CSV", index=False)