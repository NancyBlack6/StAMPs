import pandas as pd

# 读取Excel文件
train_data = pd.read_csv('D:\课题\订书肽\project\原始/原始数据.CSV')
test_data = pd.read_csv('D:\课题\订书肽\project\原始/样本数据全.CSV')
print(test_data)

# 定义筛选函数
test_data_selected = test_data.reindex(columns=train_data.columns, fill_value=1)

# 使用筛选函数筛选行
print(test_data_selected)

test_data_selected.to_csv("D:\课题\订书肽\project\原始/样本数据筛.CSV", index=False)