import subprocess
import pandas as pd
# 定义要运行预测模型文件列表
file_list = ['ANN.py', 'CNN.py', 'DT.py', 'KNN.py', 'LGBM.py', 'LSTM.py', 'NB.py', 'RF.py', 'SVM,py', 'XGB.py']

# 依次运行每个预测模型件
for file in file_list:
    subprocess.run(['python', file])

# 活性预测结果汇总
pep = pd.read_csv('D:/课题/订书肽/project/原始/sequence-pred.csv', skiprows=[0])
ANN = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果ANN.csv', skiprows=[0])
CNN = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果CNN.csv', skiprows=[0])
LSTM = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果LSTM.csv', skiprows=[0])
DT = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果DT.csv', skiprows=[0])
KNN = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果KNN.csv', skiprows=[0])
LGBM = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果LGBM.csv', skiprows=[0])
NB = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果NB.csv', skiprows=[0])
RF = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果RF.csv', skiprows=[0])
SVM = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果svm.csv', skiprows=[0])
XGB = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果XGB.csv', skiprows=[0])

id = pep.iloc[:, :1]
seq = pep.iloc[:, 2:]
combined_result = pd.concat([id, seq, ANN, CNN, LSTM, DT, KNN, LGBM, NB, RF, SVM, XGB], axis=1, keys=['id', 'seq', 'ANN', 'CNN', 'LSTM', 'DT', 'KNN', 'LGBM', 'NB', 'RF', 'SVM', 'XGB'])
# combined_result = pd.concat([seq, combined], axis=1)

combined_result = combined_result.reset_index(drop=True)

print(combined_result)

combined_result.to_csv("D:/课题/订书肽/project/predict result/总预测结果总.csv", index=False)
# 活性预测结果汇总结束

# 可能性结果汇总
pep = pd.read_csv('D:/课题/订书肽/project/原始/sequence-pred.csv', skiprows=[0])
ANN = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析ANN.csv', skiprows=[0])
CNN = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析CNN.csv', skiprows=[0])
LSTM = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析LSTM.csv', skiprows=[0])
DT = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析DT.csv', skiprows=[0])
KNN = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析KNN.csv', skiprows=[0])
LGBM = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析LGBM.csv', skiprows=[0])
NB = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析NB.csv', skiprows=[0])
RF = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析RF.csv', skiprows=[0])
SVM = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析svm.csv', skiprows=[0])
XGB = pd.read_csv('D:/课题/订书肽/project/predict result/强活性可能性分析XGB.csv', skiprows=[0])

id = pep.iloc[:, :1]
seq = pep.iloc[:, 2:]
combined_result = pd.concat([id, seq, ANN.iloc[:, 1], CNN, LSTM, DT.iloc[:, 1], KNN.iloc[:, 1], LGBM.iloc[:, 1], NB.iloc[:, 1], RF.iloc[:, 1], SVM.iloc[:, 1], XGB.iloc[:, 1]], axis=1, keys=['id', 'seq', 'ANN', 'CNN', 'LSTM', 'DT', 'KNN', 'LGBM', 'NB', 'RF', 'SVM', 'XGB'])

combined_result = combined_result.reset_index(drop=True)

print(combined_result)

combined_result.to_csv("D:/课题/订书肽/project/predict result/总强活性结果.csv", index=False)
# 可能性结果汇总结束