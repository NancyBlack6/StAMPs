import pandas as pd

pep = pd.read_csv('D:/课题/订书肽/project/原始/sequence-pred.csv', skiprows=[0])
ANN = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果ANN.csv', skiprows=[0])
CNN = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果CNN.csv', skiprows=[0])
LSTM = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果LSTM.csv', skiprows=[0])
DT = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果DT.csv', skiprows=[0])
KNN = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果KNN.csv', skiprows=[0])
LGBM = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果LGBM.csv', skiprows=[0])
NB = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果NB.csv', skiprows=[0])
RF = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果RF.csv', skiprows=[0])
SVM = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果svm.csv', skiprows=[0])
XGB = pd.read_csv('D:/课题/订书肽/project/predict result/预测结果XGB.csv', skiprows=[0])

id = pep.iloc[:, :1]
seq = pep.iloc[:, 2:]
combined_result = pd.concat([id, seq, ANN, CNN, LSTM, DT, KNN, LGBM, NB, RF, SVM, XGB], axis=1, keys=['id', 'seq', 'ANN', 'CNN', 'LSTM', 'DT', 'KNN', 'LGBM', 'NB', 'RF', 'SVM', 'XGB'])
# combined_result = pd.concat([seq, combined], axis=1)

combined_result = combined_result.reset_index(drop=True)


# combined_result = combined_result.drop([1], axis=0)
print(combined_result)

combined_result.to_csv("D:/课题/订书肽/project/predict result/总预测结果总.csv", index=False)